import os
import joblib
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from preprocess import load_and_preprocess_data

# Load data
X, y, scaler = load_and_preprocess_data()
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Print feature names to verify they match during prediction
print(f"✅ Feature names used for training: {list(X_train[0])}")  

# Train model
model = DecisionTreeClassifier(random_state=42)
model.fit(X_train, y_train)

# Ensure models directory exists
models_dir = os.path.join(os.path.dirname(__file__), 'models')
os.makedirs(models_dir, exist_ok=True)

# Save model and scaler
model_path = os.path.join(models_dir, 'fraud_model.sav')
scaler_path = os.path.join(models_dir, 'scaler.sav')

joblib.dump(model, model_path)
joblib.dump(scaler, scaler_path)

print(f"✅ Model and scaler saved successfully!\n📁 Model Path: {model_path}\n📁 Scaler Path: {scaler_path}")


