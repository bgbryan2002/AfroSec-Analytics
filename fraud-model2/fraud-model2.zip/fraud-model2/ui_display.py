import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import pandas as pd
import winsound
import random  

# Load dataset
csv_file = "all_transactions.csv"
df = pd.read_csv(csv_file)

# Function to create real-time UI
def show_fraud_summary():
    window = tk.Tk()
    window.title("SentinelPay - Live Fraud Detection")
    window.geometry("1000x650")
    window.configure(bg="#FFFFFF")

    # Load and display SentinelPay logo
    try:
        image = Image.open("sentinelpay_logo.png")
        image = image.resize((320, 140), Image.LANCZOS)  
        photo = ImageTk.PhotoImage(image)

        img_label = tk.Label(window, image=photo, bg="#FFFFFF", bd=5, relief="ridge")
        img_label.image = photo  
        img_label.pack(pady=10)
    except Exception as e:
        print(f"⚠️ Error loading image: {e}")

    # Title Label
    title = tk.Label(window, text="SentinelPay - AI Fraud Detection", 
                     font=("Orbitron", 22, "bold"), bg="#FFFFFF", fg="black")  
    title.pack(pady=5)

    # Fraud Count & Amount Section
    fraud_count_var = tk.StringVar()
    total_amount_var = tk.StringVar()
    fraud_count_var.set(f"🚨 Total Fraud Transactions: 0")
    total_amount_var.set(f"💰 Fraudulent Transaction Amount: $0.00")

    fraud_count_label = tk.Label(window, textvariable=fraud_count_var, 
                                 font=("Orbitron", 14, "bold"), 
                                 bg="white", fg="black", padx=20, pady=10, 
                                 relief="solid", borderwidth=2, highlightbackground="#007BFF")
    fraud_count_label.pack(pady=5)

    total_amount_label = tk.Label(window, textvariable=total_amount_var, 
                                  font=("Orbitron", 14, "bold"), 
                                  bg="white", fg="black", padx=20, pady=10, 
                                  relief="solid", borderwidth=2, highlightbackground="#007BFF")
    total_amount_label.pack(pady=5)

    # Transaction Table with **Black Row Separators**
    frame = tk.Frame(window, bg="#FFFFFF", padx=10, pady=10)
    frame.pack(pady=10, fill="both", expand=True)

    tree = ttk.Treeview(frame, columns=("Transaction ID", "Amount", "Fraud"), show="headings", height=15)
    tree.column("Transaction ID", width=120, anchor="center")
    tree.column("Amount", width=200, anchor="center")
    tree.column("Fraud", width=100, anchor="center")

    # **Make column titles bigger, bold, and centered**
    tree.heading("Transaction ID", text="Transaction ID", anchor="center")
    tree.heading("Amount", text="Amount ($)", anchor="center")
    tree.heading("Fraud", text="Fraudulent?", anchor="center")

    tree.pack(fill="both", expand=True)

    # **Customize Table Appearance for Black Row Separators**
    style = ttk.Style()
    style.configure("Treeview.Heading", font=("Orbitron", 14, "bold"))  # Bold Headers
    style.configure("Treeview", rowheight=25, background="white", foreground="black", borderwidth=1, relief="solid")
    style.configure("Treeview", highlightthickness=1, highlightbackground="black", highlightcolor="black")  # **Black Lines**

    # **Define tag styles for fraud highlighting**
    tree.tag_configure("fraud", background="red", foreground="white")
    tree.tag_configure("normal", background="white", foreground="black")

    # **Add initial transactions**
    displayed_transactions = []
    for index, row in df.head(20).iterrows():
        is_fraud = "Fraud" if row["PredictedFraud"] == 1 else "Not Fraud"
        fraud_tag = "fraud" if is_fraud == "Fraud" else "normal"

        tree.insert("", "end", values=(index + 1, f"${row['amount']:,.2f}", is_fraud), tags=(fraud_tag,))
        displayed_transactions.append(row)

    # Fraud Sound Alert
    def play_alert_sound():
        winsound.Beep(1500, 500)  

    # **Live Updates: Add 1-4 Transactions Every 3-5 Seconds**
    def update_transactions():
        nonlocal displayed_transactions
        new_transactions = random.randint(1, 4)

        for _ in range(new_transactions):
            if len(displayed_transactions) < len(df):
                row = df.iloc[len(displayed_transactions)]
                is_fraud = "Fraud" if row["PredictedFraud"] == 1 else "Not Fraud"
                fraud_tag = "fraud" if is_fraud == "Fraud" else "normal"

                tree.insert("", "end", values=(len(displayed_transactions) + 1, f"${row['amount']:,.2f}", is_fraud), tags=(fraud_tag,))

                if is_fraud == "Fraud":
                    play_alert_sound()

                displayed_transactions.append(row)

        # **Synchronize Fraud Count & Fraud Amount**
        fraud_transactions = df["PredictedFraud"][:len(displayed_transactions)].sum()
        fraud_amount = df[df["PredictedFraud"] == 1]["amount"][:len(displayed_transactions)].sum()

        fraud_count_var.set(f"🚨 Total Fraud Transactions: {fraud_transactions}")
        total_amount_var.set(f"💰 Fraudulent Transaction Amount: ${fraud_amount:,.2f}")

        window.after(random.randint(3000, 5000), update_transactions)

    update_transactions()
    window.mainloop()

show_fraud_summary()
