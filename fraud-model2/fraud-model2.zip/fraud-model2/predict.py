import pandas as pd
import joblib
from preprocess import preprocess_data  
from sklearn.metrics import classification_report, accuracy_score

# Define color codes for terminal output
RED = "\033[91m"
GREEN = "\033[92m"
RESET = "\033[0m"

# Load trained model and scaler
model = joblib.load(r"C:\Users\49erb\Downloads\fraud-model2\models\fraud_model.sav")
scaler = joblib.load(r"C:\Users\49erb\Downloads\fraud-model2\models\scaler.sav")

# Load dataset (Now includes all transactions, not just fraud)
new_data = pd.read_csv(r"C:\Users\49erb\Downloads\synthetic_fraud_dataset.csv")
print(f"✅ Loaded dataset with {len(new_data)} transactions.")

# Rename columns to match trained model
rename_columns = {
    'oldbalanceOrg': 'oldbalanceorg',
    'newbalanceOrig': 'newbalanceorg',
    'oldbalanceDest': 'oldbalancedest',
    'newbalanceDest': 'newbalancedest'
}
new_data.rename(columns=rename_columns, inplace=True)

# Preprocess data
new_data_scaled = preprocess_data(new_data, scaler)

# Predict using the model
predictions = model.predict(new_data_scaled)
new_data["PredictedFraud"] = predictions  # Add prediction column

# Display First 100 Transactions in Terminal (No Transaction Amount)
print("\n✅ First 100 Transactions:")
print(f"{'Index':<10}{'Status':<10}")
print("="*30)

for i, (index, row) in enumerate(new_data.iterrows()):
    if i >= 100:  # Show first 100 transactions
        break
    fraud_status = "Fraud" if row["PredictedFraud"] == 1 else "Not Fraud"
    color = RED if row["PredictedFraud"] == 1 else GREEN
    print(f"{index+1:<10}{color}{fraud_status}{RESET}")

# Count fraud transactions & total fraud amount
total_fraud_transactions = new_data["PredictedFraud"].sum()
total_fraud_amount = new_data.loc[new_data["PredictedFraud"] == 1, "amount"].sum()

# Output fraud summary
print(f"\n🚨 Total Fraud Transactions: {RED}{total_fraud_transactions}{RESET}")
print(f"💰 Total Fraudulent Transaction Amount: {RED}${total_fraud_amount:,.2f}{RESET}")

# Save entire dataset (fraud + non-fraud)
new_data.to_csv("all_transactions.csv", index=False)
print(f"✅ All transactions saved to 'all_transactions.csv'.")

# Evaluate predictions
if 'isFraud' in new_data.columns or 'isfraud' in new_data.columns:
    fraud_label = 'isFraud' if 'isFraud' in new_data.columns else 'isfraud'
    print("\n✅ Model Accuracy:", accuracy_score(new_data[fraud_label], predictions))
    print("\nClassification Report:\n", classification_report(new_data[fraud_label], predictions, target_names=["Not Fraud", "Fraud"]))

# Import UI after saving transactions
from ui_display import show_fraud_summary

# ✅ Ensure UI runs only if script is executed directly
if __name__ == "__main__":
    print("🚀 Launching SentinelPay UI...")
    show_fraud_summary()  # Opens UI window

